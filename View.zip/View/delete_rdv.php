<?php
include '../Controller/rendez_vousC.php';

// Traitement de la suppression
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        $rendez_vous = new rendez_vousC();
        $rendez_vous->deleterendez_vous($_POST['id']);
        echo 'Le rendez-vous a été supprimé avec succès.';
    } else {
        echo 'Veuillez fournir un ID de rendez-vous valide.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">  
    <title>Visual Admin Dashboard - Home</title>
    <meta name="description" content="">
    <meta name="author" content="templatemo">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700' rel='stylesheet' type='text/css'>
    <link href="../assets2/css/font-awesome.min.css" rel="stylesheet">
    <link href="../assets2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets2/css/templatemo-style.css" rel="stylesheet">
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>  
    <div class="templatemo-flex-row">
        <div class="templatemo-sidebar">
            <header class="templatemo-site-header">
                <div class="square"></div>
                <h1>Visual Admin</h1>
            </header>
            <div class="profile-photo-container">
                <img src="../assets2/images/profile-photo.jpg" alt="Profile Photo" class="img-responsive">  
                <div class="profile-photo-overlay"></div>
            </div>
            <!-- Search box -->
            <form class="templatemo-search-form" role="search">
                <div class="input-group">
                    <button type="submit" class="fa fa-search"></button>
                    <input type="text" class="form-control" placeholder="Search" name="srch-term" id="srch-term">           
                </div>
            </form>
            <!-- ... (autres éléments du menu) ... -->
        </div>
        <div class="templatemo-content col-1 light-gray-bg">
            <div class="templatemo-flex-row flex-content-row templatemo-overflow-hidden">
                <div class="col-1 templatemo-overflow-hidden">
                    <div class="templatemo-content-widget white-bg templatemo-overflow-hidden">
                        <!-- Widget content here -->
                        <div id="pie_chart_div" class="templatemo-chart"></div>
                        <div id="bar_chart_div" class="templatemo-chart"></div>
                        <!-- ... -->
                        <!-- Form for deletion -->
                        <form method="POST" action="">
                            <label for="id">ID du rendez-vous à supprimer :</label>
                            <input type="text" name="id" id="id" required>
                            <button type="submit">Supprimer</button>
                        </form>
                        <!-- ... -->
                    </div>
                </div>
            </div>
            <footer class="text-right">
                <p>Copyright &copy; 2084 Company Name | Design: Template Mo</p>
            </footer>         
        </div>
    </div>

    <!-- JS and Scripts -->
    <script src="../assets2/js/jquery-1.11.2.min.js"></script>
    <script src="../assets2/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="https://www.google.com/jsapi"></script>
    <script>
        // ... (le reste du code JavaScript) ...
    </script>
    <script type="text/javascript" src="../assets2/js/templatemo-script.js"></script>
</body>
</html>
