<?php
include "../Controller/rendez_vousC.php";

$c = new rendez_vousC();
$tab= $c->listrendez_vous();

?>

<center>
    <h1>List of rendez_vous</h1>
    <h2>
        <a href="add_rdv.php">Add rendez_vous</a>
    </h2>
</center>
<table border="1" align="center" width="70%">
    <tr>
        <th>Id</th>
        <th>sujet</th>
        <th>demande_rdv</th>
        <th>etat</th>
        <th>Update</th>
        <th>Delete</th>
    </tr>


    <?php
    foreach ($tab as $rendez_vous) {
    ?>




        <tr>
            <td><?= $rendez_vous['id']; ?></td>
            <td><?= $rendez_vous['sujet']; ?></td>
            <td><?= $rendez_vous['demande_rdv']; ?></td>
            <td><?= $rendez_vous['etat']; ?></td>
            <td align="center">
                <form method="POST" action="update_rdv.php">
                    <input type="submit" name="update" value="Update">
                    <input type="hidden" value=<?PHP echo $rendez_vous['id']; ?> name="id">
                </form>
            </td>
            <td>
                <a href="delete_rdv.php?id=<?php echo $rendez_vous['id']; ?>">Delete</a>
            </td>
        </tr>
    <?php
    }
    ?>
</table>