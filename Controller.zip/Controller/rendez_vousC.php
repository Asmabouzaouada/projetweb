<?php

require '../config.php';

class rendez_vousC
{

    public function listrendez_vous()
    {
        $sql = "SELECT * FROM rendez_vous";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Error:' . $e->getMessage());
        }
    }

    function deleterendez_vous($ide)
    {
        $sql = "DELETE FROM rendez_vous WHERE id= :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $ide);

        try {
            $req->execute();
        } catch (Exception $e) {
            die('Error:' . $e->getMessage());
        }
    }

    function addrendez_vous($rendez_vous)
    {
        $sql = "INSERT INTO rendez_vous 
        VALUES (NULL,:sujet, :demande_rdv,:etat)";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'sujet' => $rendez_vous->getsujet(),
                'demande_rdv' => $rendez_vous->getdemande_rdv(),
                'etat' => $rendez_vous->getetat(),
            ]);
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }
   

    function showrendez_vous($id)
    {
        $sql = "SELECT * from rendez_vous where id = $id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute();
            $rendez_vous = $query->fetch();
            return $rendez_vous;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
    function updaterendez_vous($rendez_vous, $id)
    {   
        try {
            $db = config::getConnexion();
            $query = $db->prepare(
                'UPDATE rendez_vous SET 
            
                    sujet = :sujet, 
                    demande_rdv= :demande_rdv, 
                    etat = :etat
                WHERE id= :id'
            );
            
            $query->execute([
                'id'=> $id,
    
                'sujet' => $rendez_vous->getsujet(),
                'demande_vous' => $rendez_vous->getdemande_rdv(),
                'etat' => $rendez_vous->getetat(),
            ]);
            
            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }
}